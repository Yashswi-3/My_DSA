  // for (int i=0 ; i<=num ; i++){
    //     cout << i << endl ;
    //     i++ ;
    // }